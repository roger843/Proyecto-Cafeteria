@echo off
cd /d "%~dp0"
java -jar cafeteria.jar --gui
if errorlevel 1 pause
