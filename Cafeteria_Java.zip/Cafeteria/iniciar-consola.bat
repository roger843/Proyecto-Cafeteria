@echo off
chcp 65001 >nul
cd /d "%~dp0"
java -jar cafeteria.jar --consola
if errorlevel 1 pause
