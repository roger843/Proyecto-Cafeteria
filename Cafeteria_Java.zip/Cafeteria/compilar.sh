#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes build/test-classes
find src/main/java -name '*.java' | sort > build/main-sources.txt
find src/test/java -name '*.java' | sort > build/test-sources.txt
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 21 -target 21 -Xlint:all -d build/classes @build/main-sources.txt
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 21 -target 21 -Xlint:all -cp build/classes -d build/test-classes @build/test-sources.txt
java -cp build/classes:build/test-classes cafeteria.Pruebas
java -m jdk.jartool/sun.tools.jar.Main --create --file cafeteria.jar --main-class cafeteria.Main -C build/classes .
