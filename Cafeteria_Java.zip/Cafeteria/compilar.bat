@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
if not exist build\test-classes mkdir build\test-classes
powershell -NoProfile -Command "Get-ChildItem src/main/java -Recurse -Filter *.java | ForEach-Object { $_.FullName.Substring((Get-Location).Path.Length + 1).Replace([char]92,[char]47) } | Set-Content -Encoding ascii build/main-sources.txt" || exit /b 1
powershell -NoProfile -Command "Get-ChildItem src/test/java -Recurse -Filter *.java | ForEach-Object { $_.FullName.Substring((Get-Location).Path.Length + 1).Replace([char]92,[char]47) } | Set-Content -Encoding ascii build/test-sources.txt" || exit /b 1
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 21 -target 21 -Xlint:all -d build\classes @build\main-sources.txt || exit /b 1
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -source 21 -target 21 -Xlint:all -cp build\classes -d build\test-classes @build\test-sources.txt || exit /b 1
java -cp "build\classes;build\test-classes" cafeteria.Pruebas || exit /b 1
java -m jdk.jartool/sun.tools.jar.Main --create --file cafeteria.jar --main-class cafeteria.Main -C build\classes . || exit /b 1
echo Listo: cafeteria.jar
