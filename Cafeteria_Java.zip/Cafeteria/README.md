# Cafetería · Sistema de pedidos

Proyecto de Patrones de Diseño en Java. Integrantes: Roger Barros, Andres Rodriguez y Juan Gaitan.

La aplicación ofrece una interfaz gráfica Swing y una consola interactiva. Ambas usan el mismo núcleo y la misma carpeta de datos al iniciarlas desde la carpeta del proyecto.

## Ejecutar

Requiere Java 21 o posterior. Swing necesita un escritorio gráfico. Extrae el ZIP completo antes de abrir los archivos.

| Modo | En Windows | Desde una terminal |
| --- | --- | --- |
| Gráfico | Doble clic en `iniciar-grafica.bat` | `java -jar cafeteria.jar --gui` |
| Consola | Doble clic en `iniciar-consola.bat` | `java -jar cafeteria.jar --consola` |

Ejecuta los comandos desde la carpeta que contiene el JAR. Si recibiste únicamente un clon del repositorio, compila primero para generar el JAR.

## Usuarios de demostración

| Usuario | Contraseña inicial | Permisos específicos |
| --- | --- | --- |
| `admin` | `admin123` | Todas las operaciones, gestión de catálogos y promociones, respaldos y restauración. |
| `mesero` | `mesero123` | Registra pedidos, personaliza productos, arma y guarda combos, y entrega pedidos listos. |
| `cocina` | `cocina123` | Avanza un pedido de pendiente a en preparación y de en preparación a listo. |
| `caja` | `caja123` | Registra pagos, movimientos y cierres. Consulta ventas y cierres anteriores. |

Todos pueden consultar el menú y el historial de pedidos. Cada área tiene su propia bandeja de avisos. El administrador puede consultar las tres. Para personalizar las contraseñas antes de ejecutar la aplicación, define las variables de entorno `CAFETERIA_CLAVE_ADMIN`, `CAFETERIA_CLAVE_MESERO`, `CAFETERIA_CLAVE_COCINA` y `CAFETERIA_CLAVE_CAJA`.

## Funcionalidades

| Requisitos | Implementación |
| --- | --- |
| RF-01 | Crear, consultar, editar y eliminar bebidas y platos. |
| RF-02 y RF-03 | Administrar adiciones por tipo de producto. Añadir o quitar ingredientes y ver el cambio de precio y descripción en cada paso. |
| RF-04 | Armar combos por etapas con al menos dos productos, guardarlos con un código y reutilizarlos en nuevos pedidos. |
| RF-06 y RF-07 | Registrar pedidos con cliente o mesa, cantidades y precio final. Avanzar por pendiente, en preparación, listo y entregado. |
| RF-08 | Generar un aviso para cocina, caja y mesero después de cada cambio confirmado. Las bandejas se recuperan al reiniciar. |
| RF-09 y RF-10 | Crear, editar, activar o desactivar promociones por día de la semana. Cuando coinciden varias promociones, se aplica el mayor porcentaje al subtotal. |
| RF-11 | Registrar un pago por pedido, en efectivo, con tarjeta o por transferencia. Se conserva el importe, fecha y método. |
| RF-12 | Registrar ingresos y egresos de efectivo. Cerrar la caja una vez por fecha y consultar ingresos, egresos, efectivo y detalle de movimientos. |
| RF-13 y RF-14 | Generar reportes de ventas por fecha de pago con ambos extremos incluidos. Consultar pedidos, cambios de estado, pagos y cierres anteriores. |

La fecha de operación corresponde al reloj local del equipo. Los importes se manejan en pesos colombianos con dos decimales. Los pedidos y los combos guardados conservan los productos, adiciones y precios de cuando se armaron. Los avisos se reciben dentro del programa. El sistema mantiene una sesión local a la vez.

### Datos y respaldos

La carpeta `datos/` se crea automáticamente. Los cambios confirmados se guardan en `datos/cafeteria.dat` con escritura temporal y reemplazo atómico. La consola y Swing pueden alternarse cerrando primero la instancia que usa esa carpeta. Para usar una carpeta independiente:

```sh
java -Dcafeteria.datos=datos-prueba -jar cafeteria.jar --consola
```

En **Administración**, usa **Crear respaldo** para guardar una copia en una ruta nueva dentro de una carpeta existente. **Restaurar respaldo** pide confirmación antes de reemplazar los datos activos. Las credenciales que definas mediante variables de entorno se configuran por separado.

## Arquitectura

| Paquete | Responsabilidad |
| --- | --- |
| `cafeteria.presentacion` | Menús, formularios y diálogos en consola y Swing. |
| `cafeteria.aplicacion` | Servicios de pedidos, menú, promociones, caja y acceso por rol. |
| `cafeteria.dominio` | Productos, combos, pedidos, promociones, pagos y reglas de negocio. |
| `cafeteria.aplicacion.repositorio` | Contratos de acceso a los datos. |
| `cafeteria.infraestructura` | Repositorios implementados sobre un archivo local. |

| Patrón | Clases | Uso |
| --- | --- | --- |
| Decorator (estructural) | `Producto`, `ProductoMenu`, `ProductoDecorador`, `Adicion` | Cada adición envuelve un producto y suma su aporte al precio y a la descripción. |
| Builder (creacional) | `ComboBuilder`, `ConstructorCombo`, `Combo` | Construcción incremental del combo y validación de sus componentes. |
| Observer (comportamiento) | `Pedido`, `ObservadorPedido`, `ObservadorCocina`, `ObservadorCaja`, `ObservadorMesero` | Después de guardar el cambio, el pedido notifica a los observadores suscritos. |

## Compilar y probar

Con un **JDK 21 o posterior** en el PATH, ejecuta desde la carpeta del proyecto:

- Windows: `compilar.bat`
- Linux y macOS: `sh compilar.sh`

Ambos scripts compilan el código y ejecutan `cafeteria.Pruebas`. Si todas las pruebas pasan, generan `cafeteria.jar`. No se requieren librerías externas ni acceso a Internet. Las pruebas están en `src/test/java` y comprueban los tres patrones, los permisos, las promociones, el flujo de caja, el reinicio y la restauración.

## Recorrido de demostración

1. Entra como `admin` y crea una promoción para el día actual.
2. En **Registrar pedido**, escribe una mesa, añade un café y selecciónale leche. Agrega también un combo con dos productos. Revisa el subtotal y el descuento y confirma.
3. Usa **Avanzar estado** para llevar el pedido a entregado. Abre **Consultar avisos** y selecciona la bandeja que quieres revisar.
4. Registra un pago y un movimiento de efectivo. Consulta el reporte de hoy y guarda el cierre.
5. Crea un respaldo, cierra la aplicación y vuelve a abrirla en el otro modo. El historial de pedidos, las ventas y el cierre siguen disponibles.
