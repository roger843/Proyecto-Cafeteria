package cafeteria.aplicacion;


import cafeteria.aplicacion.Acceso.Rol;
import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.repositorio.CajaRepository;
import cafeteria.dominio.*;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public record CajaService(CajaRepository repositorio, PedidoService pedidos, Clock reloj) {
    public Pago registrarPago(Sesion sesion, int pedidoId, Pago.Metodo metodo) {
        sesion.exigir(Rol.CAJA);
        LocalDateTime ahora = LocalDateTime.now(reloj);
        comprobarCajaAbierta(ahora.toLocalDate());
        if (repositorio.listarPagos().stream().anyMatch(p -> p.pedidoId() == pedidoId))
            throw new IllegalStateException("El pedido ya tiene un pago registrado.");
        Pago pago = new Pago(pedidoId, pedidos.buscar(pedidoId).total(), ahora, Objects.requireNonNull(metodo));
        repositorio.guardarPago(pago);
        return pago;
    }

    public void registrarMovimiento(Sesion sesion, String descripcion, BigDecimal valor, boolean ingreso) {
        sesion.exigir(Rol.CAJA);
        LocalDateTime ahora = LocalDateTime.now(reloj);
        comprobarCajaAbierta(ahora.toLocalDate());
        BigDecimal importe = Datos.importe(valor);
        if (importe.signum() == 0) throw new IllegalArgumentException("El importe debe ser positivo.");
        repositorio.guardarMovimiento(new MovimientoCaja(Datos.texto(descripcion, "Concepto"),
                ingreso ? importe : importe.negate(), ahora));
    }

    public CierreCaja resumen(Sesion sesion) {
        sesion.exigir(Rol.CAJA);
        LocalDate fecha = LocalDate.now(reloj);
        List<MovimientoCaja> movimientos = new ArrayList<>();
        BigDecimal efectivo = BigDecimal.ZERO;
        for (Pago pago : repositorio.listarPagos()) {
            if (!pago.fecha().toLocalDate().equals(fecha)) continue;
            movimientos.add(new MovimientoCaja("Pedido #" + pago.pedidoId() + " · " + pago.metodo(),
                    pago.valor(), pago.fecha()));
            if (pago.metodo() == Pago.Metodo.EFECTIVO) efectivo = efectivo.add(pago.valor());
        }
        for (MovimientoCaja movimiento : repositorio.listarMovimientos()) {
            if (!movimiento.fecha().toLocalDate().equals(fecha)) continue;
            movimientos.add(movimiento);
            efectivo = efectivo.add(movimiento.valor());
        }
        movimientos.sort(Comparator.comparing(MovimientoCaja::fecha));
        BigDecimal ingresos = BigDecimal.ZERO;
        BigDecimal egresos = BigDecimal.ZERO;
        for (MovimientoCaja movimiento : movimientos) {
            if (movimiento.valor().signum() >= 0) ingresos = ingresos.add(movimiento.valor());
            else egresos = egresos.subtract(movimiento.valor());
        }
        return new CierreCaja(fecha, ingresos, egresos, efectivo, movimientos);
    }

    public CierreCaja cerrarCaja(Sesion sesion) {
        CierreCaja cierre = resumen(sesion);
        comprobarCajaAbierta(cierre.fecha());
        repositorio.guardarCierre(cierre);
        return cierre;
    }

    public List<CierreCaja> cierres(Sesion sesion) {
        sesion.exigir(Rol.CAJA);
        return repositorio.listarCierres();
    }

    public List<Pago> pagos(Sesion sesion) {
        sesion.exigir(Rol.CAJA);
        return repositorio.listarPagos();
    }

    public ReporteVentas generarReporte(Sesion sesion, LocalDate inicio, LocalDate fin) {
        sesion.exigir(Rol.CAJA);
        if (fin.isBefore(inicio)) throw new IllegalArgumentException("El inicio debe ser anterior o igual al fin.");
        List<Pago> pagos = pagos(sesion).stream().filter(p -> {
            LocalDate dia = p.fecha().toLocalDate();
            return !dia.isBefore(inicio) && !dia.isAfter(fin);
        }).toList();
        BigDecimal total = pagos.stream().map(Pago::valor).reduce(BigDecimal.ZERO, BigDecimal::add);
        return new ReporteVentas(inicio, fin, total, pagos);
    }

    private void comprobarCajaAbierta(LocalDate fecha) {
        if (repositorio.listarCierres().stream().anyMatch(c -> c.fecha().equals(fecha)))
            throw new IllegalStateException("La caja ya está cerrada para este día.");
    }
}
