package cafeteria.aplicacion;


import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.repositorio.RespaldoRepository;
import java.nio.file.Path;

public record Sistema(Acceso acceso, ProductoService productos, PromocionService promociones,
                      PedidoService pedidos, CajaService caja, RespaldoRepository respaldo) {
    public void respaldar(Sesion sesion, Path destino) {
        sesion.exigir();
        respaldo.respaldar(destino);
    }

    public void restaurar(Sesion sesion, Path origen) {
        sesion.exigir();
        respaldo.restaurar(origen);
        pedidos.reconstruirBandejas();
    }
}
