package cafeteria.aplicacion;


import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.Acceso.Rol;
import cafeteria.aplicacion.repositorio.ProductoRepository;
import cafeteria.dominio.*;
import java.util.List;

public record ProductoService(ProductoRepository repositorio) {
    public List<ProductoMenu> consultarMenu() { return repositorio.listarProductos(); }
    public List<Ingrediente> ingredientes() { return repositorio.listarIngredientes(); }

    public List<ComboCatalogo> combos() { return repositorio.listarCombos(); }

    public void guardarCombo(Sesion sesion, ComboCatalogo combo) {
        sesion.exigir(Rol.MESERO);
        if (combos().stream().anyMatch(c -> c.id().equals(combo.id())))
            throw new IllegalArgumentException("Ese código de combo ya está registrado.");
        repositorio.guardarCombo(combo);
    }

    public void eliminarCombo(Sesion sesion, String id) {
        sesion.exigir();
        repositorio.eliminarCombo(id);
    }

    public void guardarProducto(Sesion sesion, ProductoMenu producto) {
        sesion.exigir();
        repositorio.guardarProducto(producto);
    }

    public void eliminarProducto(Sesion sesion, String id) {
        sesion.exigir();
        repositorio.eliminarProducto(id);
    }

    public void guardarIngrediente(Sesion sesion, Ingrediente ingrediente) {
        sesion.exigir();
        repositorio.guardarIngrediente(ingrediente);
    }

    public void eliminarIngrediente(Sesion sesion, String id) {
        sesion.exigir();
        repositorio.eliminarIngrediente(id);
    }

    public Producto personalizar(ProductoMenu base, List<Ingrediente> ingredientes) {
        Producto resultado = base;
        for (Ingrediente ingrediente : ingredientes) resultado = new Adicion(resultado, ingrediente);
        return resultado;
    }

    public ComboBuilder iniciarCombo(String nombre) {
        return new ConstructorCombo().conNombre(nombre);
    }
}
