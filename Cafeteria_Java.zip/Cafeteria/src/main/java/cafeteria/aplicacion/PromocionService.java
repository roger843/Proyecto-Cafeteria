package cafeteria.aplicacion;


import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.repositorio.PromocionRepository;
import cafeteria.dominio.PromocionPorDia;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

public record PromocionService(PromocionRepository repositorio) {
    public List<PromocionPorDia> listar() { return repositorio.listarPromociones(); }

    public void guardar(Sesion sesion, PromocionPorDia promocion) {
        sesion.exigir();
        repositorio.guardarPromocion(promocion);
    }

    public BigDecimal calcularDescuento(BigDecimal subtotal, LocalDate fecha) {
        return listar().stream().filter(p -> p.estaVigente(fecha))
                .max(Comparator.comparing(PromocionPorDia::porcentaje))
                .map(p -> p.calcularDescuento(subtotal)).orElse(BigDecimal.ZERO.setScale(2));
    }
}
