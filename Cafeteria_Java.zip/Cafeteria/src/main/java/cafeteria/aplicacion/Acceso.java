package cafeteria.aplicacion;


import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public final class Acceso {
    public enum Rol { ADMIN, MESERO, COCINA, CAJA }

    public static final class Sesion {
        private final Rol rol;

        private Sesion(Rol rol) { this.rol = rol; }
        public Rol rol() { return rol; }

        public boolean permite(Rol... roles) {
            if (rol == Rol.ADMIN) return true;
            for (Rol autorizado : roles) if (rol == autorizado) return true;
            return false;
        }

        public void exigir(Rol... roles) {
            if (!permite(roles)) throw new IllegalStateException("Tu usuario no tiene permiso para esta operación.");
        }
    }

    public Sesion iniciar(String usuario, String clave) {
        Rol rol;
        try {
            rol = Rol.valueOf(usuario.strip().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Usuario o contraseña incorrectos.");
        }
        String configurada = System.getenv("CAFETERIA_CLAVE_" + rol.name());
        String esperada = configurada == null || configurada.isBlank()
                ? rol.name().toLowerCase(Locale.ROOT) + "123" : configurada;
        if (!MessageDigest.isEqual(esperada.getBytes(StandardCharsets.UTF_8), clave.getBytes(StandardCharsets.UTF_8)))
            throw new IllegalArgumentException("Usuario o contraseña incorrectos.");
        return new Sesion(rol);
    }
}
