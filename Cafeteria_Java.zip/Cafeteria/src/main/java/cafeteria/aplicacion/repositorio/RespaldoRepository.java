package cafeteria.aplicacion.repositorio;


import java.nio.file.Path;

public interface RespaldoRepository {
    void respaldar(Path destino);
    void restaurar(Path origen);
}
