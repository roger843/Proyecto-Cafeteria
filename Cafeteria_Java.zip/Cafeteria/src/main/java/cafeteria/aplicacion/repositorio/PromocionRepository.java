package cafeteria.aplicacion.repositorio;


import cafeteria.dominio.PromocionPorDia;
import java.util.List;

public interface PromocionRepository {
    List<PromocionPorDia> listarPromociones();
    void guardarPromocion(PromocionPorDia promocion);
}
