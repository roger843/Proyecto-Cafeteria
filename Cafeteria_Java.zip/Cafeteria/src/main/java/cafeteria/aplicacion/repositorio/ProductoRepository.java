package cafeteria.aplicacion.repositorio;


import cafeteria.dominio.ComboCatalogo;
import cafeteria.dominio.Ingrediente;
import cafeteria.dominio.ProductoMenu;
import java.util.List;

public interface ProductoRepository {
    List<ProductoMenu> listarProductos();
    List<Ingrediente> listarIngredientes();
    List<ComboCatalogo> listarCombos();
    void guardarCombo(ComboCatalogo combo);
    void eliminarCombo(String id);
    void guardarProducto(ProductoMenu producto);
    void eliminarProducto(String id);
    void guardarIngrediente(Ingrediente ingrediente);
    void eliminarIngrediente(String id);
}
