package cafeteria.aplicacion.repositorio;


import cafeteria.dominio.*;
import java.util.List;

public interface CajaRepository {
    List<Pago> listarPagos();
    List<MovimientoCaja> listarMovimientos();
    List<CierreCaja> listarCierres();
    void guardarPago(Pago pago);
    void guardarMovimiento(MovimientoCaja movimiento);
    void guardarCierre(CierreCaja cierre);
}
