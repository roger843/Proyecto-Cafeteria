package cafeteria.aplicacion.repositorio;


import cafeteria.dominio.Pedido;
import java.util.List;

public interface PedidoRepository {
    List<Pedido> listarPedidos();
    void guardarPedido(Pedido pedido);
}
