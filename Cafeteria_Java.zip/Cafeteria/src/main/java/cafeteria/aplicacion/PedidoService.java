package cafeteria.aplicacion;


import cafeteria.aplicacion.Acceso.Rol;
import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.repositorio.PedidoRepository;
import cafeteria.dominio.*;
import java.time.Clock;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class PedidoService {
    private final PedidoRepository repositorio;
    private final PromocionService promociones;
    private final Clock reloj;
    private final Map<Rol, List<CambioEstado>> bandejas = new EnumMap<>(Rol.class);
    private final List<ObservadorPedido> observadores;

    public PedidoService(PedidoRepository repositorio, PromocionService promociones, Clock reloj) {
        this.repositorio = repositorio;
        this.promociones = promociones;
        this.reloj = reloj;
        bandejas.put(Rol.COCINA, new ArrayList<>());
        bandejas.put(Rol.CAJA, new ArrayList<>());
        bandejas.put(Rol.MESERO, new ArrayList<>());
        observadores = List.of(new ObservadorCocina(bandejas.get(Rol.COCINA)::add),
                new ObservadorCaja(bandejas.get(Rol.CAJA)::add),
                new ObservadorMesero(bandejas.get(Rol.MESERO)::add));
        reconstruirBandejas();
    }

    public void reconstruirBandejas() {
        bandejas.values().forEach(List::clear);
        listar().stream().flatMap(pedido -> pedido.cambios().stream())
                .sorted(java.util.Comparator.comparing(CambioEstado::fecha))
                .forEach(cambio -> observadores.forEach(observador -> observador.actualizar(cambio)));
    }

    public List<Pedido> listar() { return repositorio.listarPedidos(); }

    public Pedido buscar(int id) {
        return listar().stream().filter(pedido -> pedido.id() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Pedido inexistente."));
    }

    public Pedido preparar(Sesion sesion, String cliente, List<LineaPedido> lineas) {
        sesion.exigir(Rol.MESERO);
        LocalDateTime fecha = LocalDateTime.now(reloj);
        BigDecimal descuento = promociones.calcularDescuento(Pedido.subtotal(lineas), fecha.toLocalDate());
        int id = listar().stream().mapToInt(Pedido::id).max().orElse(0) + 1;
        return new Pedido(id, cliente, fecha, lineas, descuento);
    }

    public Pedido confirmarPedido(Sesion sesion, String cliente, List<LineaPedido> lineas) {
        Pedido pedido = preparar(sesion, cliente, lineas);
        repositorio.guardarPedido(pedido);
        return pedido;
    }

    public Pedido cambiarEstado(Sesion sesion, int id, EstadoPedido estado) {
        if (estado == EstadoPedido.ENTREGADO) sesion.exigir(Rol.MESERO);
        else sesion.exigir(Rol.COCINA);
        Pedido actualizado = buscar(id).cambiarEstado(estado, LocalDateTime.now(reloj));
        repositorio.guardarPedido(actualizado);
        observadores.forEach(actualizado::agregarObservador);
        try {
            actualizado.notificarObservadores();
        } finally {
            observadores.forEach(actualizado::quitarObservador);
        }
        return actualizado;
    }

    public List<CambioEstado> avisos(Sesion sesion, Rol area) {
        if (!bandejas.containsKey(area)) throw new IllegalArgumentException("Área inválida.");
        sesion.exigir(area);
        return List.copyOf(bandejas.get(area));
    }
}
