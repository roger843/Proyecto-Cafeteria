package cafeteria.dominio;

import java.io.Serializable;
import java.util.Objects;

public record ComboCatalogo(String id, Combo combo) implements Serializable {
    public ComboCatalogo {
        id = Datos.texto(id, "Código");
        Objects.requireNonNull(combo);
    }
}
