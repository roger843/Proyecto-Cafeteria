package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;

// Las listas se guardan como copias inmutables serializables de List.copyOf.
@SuppressWarnings("serial")
public final class Pedido implements Serializable {
    private static final long serialVersionUID = 1L;
    private final int id;
    private final String cliente;
    private final LocalDateTime fecha;
    private final List<LineaPedido> lineas;
    private final BigDecimal descuento;
    private final List<CambioEstado> cambios;
    private final EstadoPedido estado;
    private transient Set<ObservadorPedido> observadores;
    private transient boolean cambioNotificado;

    public Pedido(int id, String cliente, LocalDateTime fecha, List<LineaPedido> lineas, BigDecimal descuento) {
        this(id, Datos.texto(cliente, "Cliente"), fecha, List.copyOf(lineas),
                descuento, List.of(), EstadoPedido.PENDIENTE);
        if (lineas.isEmpty()) throw new IllegalArgumentException("El pedido debe tener productos.");
        if (descuento.signum() < 0 || descuento.compareTo(calcularSubtotal()) > 0)
            throw new IllegalArgumentException("Descuento inválido.");
    }

    private Pedido(int id, String cliente, LocalDateTime fecha, List<LineaPedido> lineas,
                   BigDecimal descuento, List<CambioEstado> cambios, EstadoPedido estado) {
        this.id = id;
        this.cliente = cliente;
        this.fecha = fecha;
        this.lineas = lineas;
        this.descuento = descuento;
        this.cambios = cambios;
        this.estado = estado;
    }

    public int id() { return id; }
    public String cliente() { return cliente; }
    public LocalDateTime fecha() { return fecha; }
    public List<LineaPedido> lineas() { return lineas; }
    public BigDecimal descuento() { return descuento; }
    public EstadoPedido estado() { return estado; }
    public List<CambioEstado> cambios() { return cambios; }

    public BigDecimal calcularSubtotal() { return subtotal(lineas); }

    public static BigDecimal subtotal(List<LineaPedido> lineas) {
        return lineas.stream().map(LineaPedido::calcularTotal).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public BigDecimal total() { return calcularSubtotal().subtract(descuento); }

    public Pedido cambiarEstado(EstadoPedido nuevo, LocalDateTime momento) {
        if (nuevo != estado.siguiente()) throw new IllegalArgumentException("Transición de estado inválida.");
        List<CambioEstado> historial = new ArrayList<>(cambios);
        historial.add(new CambioEstado(id, momento, estado, nuevo));
        Pedido actualizado = new Pedido(id, cliente, fecha, lineas, descuento, List.copyOf(historial), nuevo);
        actualizado.suscriptores().addAll(suscriptores());
        return actualizado;
    }

    public void agregarObservador(ObservadorPedido observador) { suscriptores().add(observador); }
    public void quitarObservador(ObservadorPedido observador) { suscriptores().remove(observador); }

    public void notificarObservadores() {
        if (cambios.isEmpty() || cambioNotificado) return;
        cambioNotificado = true;
        CambioEstado cambio = cambios.get(cambios.size() - 1);
        for (ObservadorPedido observador : List.copyOf(suscriptores())) observador.actualizar(cambio);
    }

    private Set<ObservadorPedido> suscriptores() {
        if (observadores == null) observadores = new LinkedHashSet<>();
        return observadores;
    }
}
