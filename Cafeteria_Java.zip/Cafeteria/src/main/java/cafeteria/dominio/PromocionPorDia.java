package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Set;

public record PromocionPorDia(String id, String nombre, Set<DayOfWeek> diasAplicables,
                             BigDecimal porcentaje, boolean activa) implements Serializable {
    public PromocionPorDia {
        id = Datos.texto(id, "Código");
        nombre = Datos.texto(nombre, "Nombre");
        diasAplicables = Set.copyOf(diasAplicables);
        if (diasAplicables.isEmpty() || porcentaje.scale() > 4 || porcentaje.signum() <= 0
                || porcentaje.compareTo(BigDecimal.valueOf(100)) > 0)
            throw new IllegalArgumentException("Indica días y un porcentaje mayor a 0 y hasta 100.");
    }

    public boolean estaVigente(LocalDate fecha) { return activa && diasAplicables.contains(fecha.getDayOfWeek()); }

    public BigDecimal calcularDescuento(BigDecimal subtotal) {
        return subtotal.multiply(porcentaje).movePointLeft(2).setScale(2, RoundingMode.HALF_UP);
    }
}
