package cafeteria.dominio;


import java.math.BigDecimal;
import java.math.RoundingMode;

public final class Datos {
    private Datos() {}

    public static String texto(String valor, String campo) {
        if (valor == null || valor.isBlank() || valor.length() > 150)
            throw new IllegalArgumentException(campo + " debe tener entre 1 y 150 caracteres.");
        return valor.strip();
    }

    public static BigDecimal importe(BigDecimal valor) {
        if (valor == null || valor.scale() > 8 || valor.signum() < 0 || valor.compareTo(new BigDecimal("999999999")) > 0)
            throw new IllegalArgumentException("Importe fuera de rango.");
        return valor.setScale(2, RoundingMode.HALF_UP);
    }
}
