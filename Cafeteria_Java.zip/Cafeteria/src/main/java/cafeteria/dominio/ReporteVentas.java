package cafeteria.dominio;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record ReporteVentas(LocalDate inicio, LocalDate fin, BigDecimal totalVentas, List<Pago> pagos) {
    public ReporteVentas { pagos = List.copyOf(pagos); }
}
