package cafeteria.dominio;


@FunctionalInterface
public interface ObservadorPedido {
    void actualizar(CambioEstado cambio);
}
