package cafeteria.dominio;


import java.util.function.Consumer;

public record ObservadorCocina(Consumer<CambioEstado> bandeja) implements ObservadorPedido {
    @Override public void actualizar(CambioEstado cambio) { bandeja.accept(cambio); }
}
