package cafeteria.dominio;


public enum EstadoPedido {
    PENDIENTE, EN_PREPARACION, LISTO, ENTREGADO;

    public EstadoPedido siguiente() {
        if (this == ENTREGADO) throw new IllegalStateException("El pedido ya fue entregado.");
        return values()[ordinal() + 1];
    }
}
