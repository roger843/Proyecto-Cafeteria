package cafeteria.dominio;


public interface ComboBuilder {
    ComboBuilder conNombre(String nombre);
    ComboBuilder agregarProducto(Producto producto);
    Combo construir();
}
