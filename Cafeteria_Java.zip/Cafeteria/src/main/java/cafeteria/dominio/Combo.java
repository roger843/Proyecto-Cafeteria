package cafeteria.dominio;


import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

// Las listas se guardan como copias inmutables serializables de List.copyOf.
@SuppressWarnings("serial")
public final class Combo implements Producto {
    private static final long serialVersionUID = 1L;
    private final String nombre;
    private final List<Producto> productos;

    Combo(String nombre, List<Producto> productos) {
        this.nombre = Datos.texto(nombre, "Nombre del combo");
        this.productos = List.copyOf(productos);
    }

    public List<Producto> productos() { return productos; }
    @Override public String getNombre() { return nombre; }
    @Override public String getDescripcion() {
        return nombre + " (" + productos.stream().map(Producto::getDescripcion)
                .collect(Collectors.joining(" / ")) + ")";
    }
    @Override public BigDecimal getPrecio() {
        return productos.stream().map(Producto::getPrecio).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
