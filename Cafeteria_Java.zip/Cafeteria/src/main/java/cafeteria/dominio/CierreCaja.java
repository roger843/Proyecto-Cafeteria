package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record CierreCaja(LocalDate fecha, BigDecimal totalIngresos, BigDecimal totalEgresos,
                        BigDecimal saldoEfectivo, List<MovimientoCaja> movimientos) implements Serializable {
    public CierreCaja { movimientos = List.copyOf(movimientos); }
}
