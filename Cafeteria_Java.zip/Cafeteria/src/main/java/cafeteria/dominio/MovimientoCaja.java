package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public record MovimientoCaja(String descripcion, BigDecimal valor, LocalDateTime fecha) implements Serializable {}
