package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

public record LineaPedido(Producto producto, int cantidad) implements Serializable {
    public LineaPedido {
        Objects.requireNonNull(producto);
        if (cantidad < 1 || cantidad > 999)
            throw new IllegalArgumentException("La cantidad debe estar entre 1 y 999.");
    }

    public BigDecimal calcularTotal() { return producto.getPrecio().multiply(BigDecimal.valueOf(cantidad)); }
}
