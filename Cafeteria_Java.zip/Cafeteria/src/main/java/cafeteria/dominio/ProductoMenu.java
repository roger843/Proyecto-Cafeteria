package cafeteria.dominio;


import java.math.BigDecimal;
import java.util.Objects;

public record ProductoMenu(String id, String nombre, Tipo tipo, BigDecimal precioBase) implements Producto {
    public enum Tipo { BEBIDA, PLATO }

    public ProductoMenu {
        id = Datos.texto(id, "Código");
        nombre = Datos.texto(nombre, "Nombre");
        Objects.requireNonNull(tipo);
        precioBase = Datos.importe(precioBase);
        if (precioBase.signum() == 0) throw new IllegalArgumentException("El precio debe ser positivo.");
    }

    @Override public String getNombre() { return nombre; }
    @Override public BigDecimal getPrecio() { return precioBase; }
}
