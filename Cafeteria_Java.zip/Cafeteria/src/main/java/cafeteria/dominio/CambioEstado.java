package cafeteria.dominio;


import java.io.Serializable;
import java.time.LocalDateTime;

public record CambioEstado(int pedidoId, LocalDateTime fecha, EstadoPedido anterior, EstadoPedido nuevo)
        implements Serializable {}
