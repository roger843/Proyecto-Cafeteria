package cafeteria.dominio;


import java.util.Objects;

public abstract class ProductoDecorador implements Producto {
    private static final long serialVersionUID = 1L;
    protected final Producto componente;

    protected ProductoDecorador(Producto componente) {
        this.componente = Objects.requireNonNull(componente);
    }

    @Override public String getNombre() { return componente.getNombre(); }
}
