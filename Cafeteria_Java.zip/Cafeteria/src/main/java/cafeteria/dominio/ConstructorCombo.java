package cafeteria.dominio;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class ConstructorCombo implements ComboBuilder {
    private String nombre;
    private final List<Producto> productos = new ArrayList<>();

    @Override public ComboBuilder conNombre(String nombre) {
        this.nombre = Datos.texto(nombre, "Nombre del combo");
        return this;
    }

    @Override public ComboBuilder agregarProducto(Producto producto) {
        productos.add(Objects.requireNonNull(producto));
        return this;
    }

    @Override public Combo construir() {
        if (productos.size() < 2) throw new IllegalArgumentException("El combo requiere al menos dos productos.");
        return new Combo(nombre, productos);
    }
}
