package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

public record Ingrediente(String id, String nombre, ProductoMenu.Tipo tipo, BigDecimal precio)
        implements Serializable {
    public Ingrediente {
        id = Datos.texto(id, "Código");
        nombre = Datos.texto(nombre, "Nombre");
        Objects.requireNonNull(tipo);
        precio = Datos.importe(precio);
    }
}
