package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public record Pago(int pedidoId, BigDecimal valor, LocalDateTime fecha, Metodo metodo) implements Serializable {
    public enum Metodo { EFECTIVO, TARJETA, TRANSFERENCIA }
}
