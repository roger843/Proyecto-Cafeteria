package cafeteria.dominio;


import java.math.BigDecimal;
import java.util.Objects;

public final class Adicion extends ProductoDecorador {
    private static final long serialVersionUID = 1L;
    private final Ingrediente ingrediente;

    public Adicion(Producto componente, Ingrediente ingrediente) {
        super(componente);
        this.ingrediente = Objects.requireNonNull(ingrediente);
        Producto base = componente;
        while (base instanceof ProductoDecorador decorador) base = decorador.componente;
        if (!(base instanceof ProductoMenu menu) || menu.tipo() != ingrediente.tipo())
            throw new IllegalArgumentException("La adición no corresponde al tipo de producto.");
    }

    @Override public String getDescripcion() {
        return componente.getDescripcion() + " + " + ingrediente.nombre();
    }

    @Override public BigDecimal getPrecio() {
        return componente.getPrecio().add(ingrediente.precio());
    }
}
