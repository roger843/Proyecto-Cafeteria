package cafeteria.dominio;


import java.io.Serializable;
import java.math.BigDecimal;

public interface Producto extends Serializable {
    String getNombre();
    default String getDescripcion() { return getNombre(); }
    BigDecimal getPrecio();
}
