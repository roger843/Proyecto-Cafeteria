package cafeteria.presentacion;

public interface InterfazUsuario {
    void iniciar();
}
