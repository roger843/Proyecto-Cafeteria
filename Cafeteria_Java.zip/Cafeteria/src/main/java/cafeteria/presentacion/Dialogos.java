package cafeteria.presentacion;

import java.util.List;

interface Dialogos {
    String entrada(String titulo, String inicial);
    String clave();
    int opcion(String titulo, List<String> opciones);
    boolean confirmar(String titulo);
    void mostrar(String titulo, String contenido);
    void error(String contenido);

    final class Cancelado extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }
}
