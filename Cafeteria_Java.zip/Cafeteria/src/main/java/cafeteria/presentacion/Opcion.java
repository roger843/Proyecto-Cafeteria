package cafeteria.presentacion;

record Opcion(String grupo, String nombre, Runnable accion) {}
