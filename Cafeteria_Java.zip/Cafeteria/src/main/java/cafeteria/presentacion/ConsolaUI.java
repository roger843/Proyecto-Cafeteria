package cafeteria.presentacion;

import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.Sistema;
import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public final class ConsolaUI implements InterfazUsuario, Dialogos {
    private final Sistema sistema;
    private final Console terminal = System.console();
    private final Scanner lector = terminal == null ? new Scanner(System.in) : null;

    public ConsolaUI(Sistema sistema) { this.sistema = sistema; }

    @Override public void iniciar() {
        try {
            while (true) {
                System.out.println("\nCAFETERÍA · Iniciar sesión (0 para salir)");
                String usuario = entrada("Usuario", "");
                if (usuario.equals("0")) return;
                Sesion sesion;
                try {
                    sesion = sistema.acceso().iniciar(usuario, clave());
                } catch (IllegalArgumentException e) {
                    error(e.getMessage());
                    continue;
                }
                List<Opcion> opciones = new Operaciones(sistema, this, sesion).opciones();
                List<String> etiquetas = new ArrayList<>(opciones.stream()
                        .map(o -> o.grupo() + " · " + o.nombre()).toList());
                etiquetas.add("Cerrar sesión");
                while (true) {
                    int seleccion;
                    try {
                        seleccion = opcion("Cafetería · " + sesion.rol(), etiquetas);
                    } catch (Cancelado e) {
                        break;
                    }
                    if (seleccion == opciones.size()) break;
                    Operaciones.ejecutar(this, opciones.get(seleccion).accion());
                }
            }
        } catch (Cancelado ignorado) {
            // Se cerró la entrada de la consola.
        }
    }

    private String leer(String mensaje) {
        String linea;
        if (terminal != null) {
            linea = terminal.readLine("%s", mensaje);
        } else {
            System.out.print(mensaje);
            linea = lector.hasNextLine() ? lector.nextLine() : null;
        }
        if (linea == null) throw new Cancelado();
        return linea;
    }

    @Override public String entrada(String titulo, String inicial) {
        String valor = leer(titulo + (inicial.isEmpty() ? "" : " [" + inicial + "]") + ": ");
        return valor.isBlank() ? inicial : valor;
    }

    @Override public String clave() {
        if (terminal == null) return leer("Contraseña: ");
        char[] clave = terminal.readPassword("Contraseña: ");
        if (clave == null) throw new Cancelado();
        try {
            return new String(clave);
        } finally {
            java.util.Arrays.fill(clave, '\0');
        }
    }

    @Override public int opcion(String titulo, List<String> opciones) {
        System.out.println("\n" + titulo);
        for (int i = 0; i < opciones.size(); i++) System.out.println((i + 1) + ". " + opciones.get(i));
        while (true) {
            String opcion = leer("Opción (0 para volver): ").strip();
            try {
                int numero = Integer.parseInt(opcion);
                if (numero == 0) throw new Cancelado();
                if (numero > 0 && numero <= opciones.size()) return numero - 1;
            } catch (NumberFormatException ignorado) {
                // Se solicita de nuevo una opción válida.
            }
            error("Selecciona un número de la lista.");
        }
    }

    @Override public boolean confirmar(String titulo) {
        String respuesta = leer(titulo + " [s/N] ").strip();
        return respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("sí");
    }

    @Override public void mostrar(String titulo, String contenido) {
        System.out.println("\n" + titulo + "\n" + contenido);
    }

    @Override public void error(String contenido) { mostrar("Error", contenido); }
}
