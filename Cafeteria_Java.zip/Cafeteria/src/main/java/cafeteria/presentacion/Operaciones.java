package cafeteria.presentacion;

import cafeteria.aplicacion.Acceso.Rol;
import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.Sistema;
import cafeteria.dominio.*;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.*;
import java.util.function.Function;

final class Operaciones {
    private static final Locale ESPANOL = Locale.forLanguageTag("es-CO");
    private final Sistema sistema;
    private final Dialogos ui;
    private final Sesion sesion;

    Operaciones(Sistema sistema, Dialogos ui, Sesion sesion) {
        this.sistema = sistema;
        this.ui = ui;
        this.sesion = sesion;
    }

    List<Opcion> opciones() {
        List<Opcion> lista = new ArrayList<>();
        lista.add(new Opcion("Menú", "Consultar menú", this::menu));
        lista.add(new Opcion("Pedidos", "Historial y estado de pedidos", this::historial));
        lista.add(new Opcion("Pedidos", "Consultar avisos", this::avisos));
        if (sesion.permite(Rol.MESERO)) {
            lista.add(new Opcion("Pedidos", "Registrar pedido", this::pedido));
            lista.add(new Opcion("Menú", "Personalizar producto", () -> detalleProducto(productoPersonalizado())));
            lista.add(new Opcion("Menú", "Armar combo", this::armarComboCatalogo));
            lista.add(new Opcion("Menú", "Consultar combos guardados", () ->
                    mostrarLista("Combos guardados", sistema.productos().combos().stream()
                            .map(Operaciones::fichaCombo).toList())));
        }
        if (sesion.permite(Rol.MESERO, Rol.COCINA))
            lista.add(new Opcion("Pedidos", "Avanzar estado", this::estado));
        if (sesion.permite(Rol.CAJA)) {
            lista.add(new Opcion("Caja", "Registrar pago", this::pago));
            lista.add(new Opcion("Caja", "Registrar movimiento de efectivo", this::movimiento));
            lista.add(new Opcion("Caja", "Consultar resumen de caja", () -> mostrarCierre(sistema.caja().resumen(sesion))));
            lista.add(new Opcion("Caja", "Cerrar caja del día", this::cerrarCaja));
            lista.add(new Opcion("Caja", "Historial de cierres", this::cierres));
            lista.add(new Opcion("Caja", "Reporte e historial de ventas", this::reporte));
        }
        if (sesion.permite()) {
            lista.add(new Opcion("Administración", "Gestionar productos", this::productos));
            lista.add(new Opcion("Administración", "Gestionar adiciones", this::ingredientes));
            lista.add(new Opcion("Administración", "Gestionar promociones", this::promociones));
            lista.add(new Opcion("Administración", "Eliminar combo guardado", this::eliminarCombo));
            lista.add(new Opcion("Administración", "Crear respaldo", this::respaldar));
            lista.add(new Opcion("Administración", "Restaurar respaldo", this::restaurar));
        }
        return lista;
    }

    static void ejecutar(Dialogos ui, Runnable accion) {
        try {
            accion.run();
        } catch (Dialogos.Cancelado ignorado) {
            // La interfaz vuelve al menú.
        } catch (IllegalArgumentException | IllegalStateException | java.io.UncheckedIOException
                 | java.time.DateTimeException e) {
            ui.error(e.getMessage());
        }
    }

    private void menu() {
        mostrarLista("Menú", sistema.productos().consultarMenu().stream().map(Operaciones::ficha).toList());
    }

    private void detalleProducto(Producto producto) { ui.mostrar("Detalle", ficha(producto)); }

    private Producto productoPersonalizado() {
        ProductoMenu base = elegir("Producto base", sistema.productos().consultarMenu(), Operaciones::ficha);
        List<Ingrediente> compatibles = sistema.productos().ingredientes().stream()
                .filter(i -> i.tipo() == base.tipo()).toList();
        List<Ingrediente> seleccion = new ArrayList<>();
        while (true) {
            Producto actual = sistema.productos().personalizar(base, seleccion);
            int accion = ui.opcion("Personalización · " + ficha(actual),
                    List.of("Aceptar producto", "Agregar adición", "Quitar adición"));
            try {
                switch (accion) {
                    case 0 -> { return actual; }
                    case 1 -> {
                        List<Ingrediente> disponibles = compatibles.stream().filter(i -> !seleccion.contains(i)).toList();
                        if (disponibles.isEmpty()) ui.mostrar("Adiciones", "No hay más adiciones disponibles.");
                        else seleccion.add(elegir("Adiciones disponibles", disponibles, Operaciones::fichaIngrediente));
                    }
                    case 2 -> {
                        if (seleccion.isEmpty()) ui.mostrar("Adiciones", "Todavía no hay adiciones seleccionadas.");
                        else seleccion.remove(elegir("Quitar adición", seleccion, Operaciones::fichaIngrediente));
                    }
                    default -> throw new IllegalArgumentException("Opción inválida.");
                }
            } catch (Dialogos.Cancelado ignorado) {
                // Volver al paso actual conserva la selección que ya se hizo.
            }
        }
    }

    private void armarComboCatalogo() {
        Combo resultado = combo();
        detalleProducto(resultado);
        if (ui.confirmar("¿Guardar el combo en el menú?")) {
            String id = nuevoCodigo(sistema.productos().combos(), ComboCatalogo::id);
            sistema.productos().guardarCombo(sesion, new ComboCatalogo(id, resultado));
            ui.mostrar("Combo guardado", ficha(resultado));
        }
    }

    private void eliminarCombo() {
        ComboCatalogo entrada = elegir("Combo a eliminar", sistema.productos().combos(), Operaciones::fichaCombo);
        if (ui.confirmar("¿Eliminar " + entrada.combo().getNombre() + " del menú?"))
            sistema.productos().eliminarCombo(sesion, entrada.id());
    }

    private Combo combo() {
        ComboBuilder constructor = sistema.productos().iniciarCombo(ui.entrada("Nombre del combo", ""));
        List<String> componentes = new ArrayList<>();
        while (true) {
            int paso = ui.opcion("Combo · " + componentes.size() + " productos",
                    List.of("Agregar producto personalizado", "Ver componentes", "Terminar combo"));
            try {
                switch (paso) {
                    case 0 -> {
                        Producto producto = productoPersonalizado();
                        constructor.agregarProducto(producto);
                        componentes.add(ficha(producto));
                    }
                    case 1 -> mostrarLista("Componentes del combo", componentes);
                    case 2 -> {
                        if (componentes.size() >= 2) return constructor.construir();
                        ui.error("Selecciona al menos dos productos.");
                    }
                    default -> throw new IllegalArgumentException("Opción inválida.");
                }
            } catch (Dialogos.Cancelado ignorado) {
                // Volver al paso actual conserva la selección que ya se hizo.
            }
        }
    }

    private void pedido() {
        String cliente = ui.entrada("Cliente o mesa", "");
        List<LineaPedido> lineas = new ArrayList<>();
        while (true) {
            int opcion = ui.opcion("Pedido · " + cliente,
                    List.of("Agregar bebida o plato", "Armar y agregar combo", "Quitar línea", "Revisar y confirmar", "Agregar combo guardado"));
            try {
                switch (opcion) {
                    case 0 -> lineas.add(new LineaPedido(productoPersonalizado(), entero("Cantidad", "1")));
                    case 1 -> lineas.add(new LineaPedido(combo(), entero("Cantidad de combos", "1")));
                    case 2 -> {
                        if (lineas.isEmpty()) ui.mostrar("Pedido", "Todavía no hay líneas.");
                        else {
                            // Quitar por posición también distingue líneas idénticas.
                            List<String> nombres = lineas.stream().map(Operaciones::fichaLinea).toList();
                            lineas.remove(ui.opcion("Quitar línea", nombres));
                        }
                    }
                    case 3 -> {
                        if (lineas.isEmpty()) {
                            ui.error("Agrega un producto antes de confirmar.");
                            continue;
                        }
                        Pedido vista = sistema.pedidos().preparar(sesion, cliente, lineas);
                        ui.mostrar("Revisión del pedido", fichaPedido(vista));
                        if (!ui.confirmar("¿Registrar el pedido?")) continue;
                        Pedido registrado = sistema.pedidos().confirmarPedido(sesion, cliente, lineas);
                        ui.mostrar("Pedido registrado", fichaPedido(registrado));
                        return;
                    }
                    case 4 -> {
                        ComboCatalogo entrada = elegir("Combo guardado", sistema.productos().combos(), Operaciones::fichaCombo);
                        lineas.add(new LineaPedido(entrada.combo(), entero("Cantidad de combos", "1")));
                    }
                    default -> throw new IllegalArgumentException("Opción inválida.");
                }
            } catch (Dialogos.Cancelado ignorado) {
                // Volver al paso actual conserva la selección que ya se hizo.
            }
        }
    }

    private void historial() {
        Pedido pedido = elegir("Historial de pedidos", sistema.pedidos().listar(), Operaciones::resumenPedido);
        String cambios = pedido.cambios().stream().map(Operaciones::fichaCambio)
                .collect(java.util.stream.Collectors.joining("\n"));
        ui.mostrar("Detalle del pedido", fichaPedido(pedido) + (cambios.isEmpty() ? "" : "\n\n" + cambios));
    }

    private void estado() {
        List<Pedido> habilitados = sistema.pedidos().listar().stream().filter(p -> switch (p.estado()) {
            case PENDIENTE, EN_PREPARACION -> sesion.permite(Rol.COCINA);
            case LISTO -> sesion.permite(Rol.MESERO);
            case ENTREGADO -> false;
        }).toList();
        Pedido pedido = elegir("Pedido para actualizar", habilitados, Operaciones::resumenPedido);
        EstadoPedido estado = pedido.estado().siguiente();
        if (ui.confirmar("¿Cambiar el pedido #" + pedido.id() + " a " + etiqueta(estado) + "?")) {
            sistema.pedidos().cambiarEstado(sesion, pedido.id(), estado);
            ui.mostrar("Estado actualizado", "Pedido #" + pedido.id() + " · " + etiqueta(estado)
                    + "\nAviso enviado a cocina, caja y mesero.");
        }
    }

    private void avisos() {
        Rol area = sesion.rol();
        if (area == Rol.ADMIN) area = elegir("Bandeja de", List.of(Rol.COCINA, Rol.CAJA, Rol.MESERO), Operaciones::etiqueta);
        mostrarLista("Avisos · " + etiqueta(area),
                sistema.pedidos().avisos(sesion, area).reversed().stream().map(Operaciones::fichaCambio).toList());
    }

    private void productos() {
        int accion = ui.opcion("Productos", List.of("Crear", "Editar", "Eliminar"));
        if (accion == 2) {
            ProductoMenu producto = elegir("Producto a eliminar", sistema.productos().consultarMenu(), Operaciones::ficha);
            if (ui.confirmar("¿Eliminar " + producto.nombre() + " del menú?"))
                sistema.productos().eliminarProducto(sesion, producto.id());
            return;
        }
        ProductoMenu anterior = accion == 1
                ? elegir("Producto a editar", sistema.productos().consultarMenu(), Operaciones::ficha) : null;
        String id = anterior == null ? nuevoCodigo(sistema.productos().consultarMenu(), ProductoMenu::id) : anterior.id();
        String nombre = ui.entrada("Nombre", anterior == null ? "" : anterior.nombre());
        ProductoMenu.Tipo tipo = tipo();
        BigDecimal precio = decimal("Precio en COP", anterior == null ? "" : anterior.precioBase().toPlainString());
        sistema.productos().guardarProducto(sesion, new ProductoMenu(id, nombre, tipo, precio));
        ui.mostrar("Producto guardado", nombre);
    }

    private void ingredientes() {
        int accion = ui.opcion("Adiciones", List.of("Crear", "Editar", "Eliminar"));
        if (accion == 2) {
            Ingrediente ingrediente = elegir("Adición a eliminar", sistema.productos().ingredientes(), Operaciones::fichaIngrediente);
            if (ui.confirmar("¿Eliminar " + ingrediente.nombre() + "?"))
                sistema.productos().eliminarIngrediente(sesion, ingrediente.id());
            return;
        }
        Ingrediente anterior = accion == 1
                ? elegir("Adición a editar", sistema.productos().ingredientes(), Operaciones::fichaIngrediente) : null;
        String id = anterior == null ? nuevoCodigo(sistema.productos().ingredientes(), Ingrediente::id) : anterior.id();
        String nombre = ui.entrada("Nombre", anterior == null ? "" : anterior.nombre());
        ProductoMenu.Tipo tipo = tipo();
        BigDecimal precio = decimal("Precio adicional en COP", anterior == null ? "" : anterior.precio().toPlainString());
        sistema.productos().guardarIngrediente(sesion, new Ingrediente(id, nombre, tipo, precio));
        ui.mostrar("Adición guardada", nombre);
    }

    private ProductoMenu.Tipo tipo() {
        return elegir("Tipo de producto", List.of(ProductoMenu.Tipo.values()), Operaciones::etiqueta);
    }

    private void promociones() {
        List<PromocionPorDia> existentes = sistema.promociones().listar();
        int accion = ui.opcion("Promociones por día", List.of("Consultar", "Crear", "Editar", "Activar o desactivar"));
        if (accion == 0) {
            mostrarLista("Promociones", existentes.stream().map(Operaciones::fichaPromocion).toList());
            return;
        }
        PromocionPorDia anterior = accion >= 2 ? elegir("Promoción", existentes, Operaciones::fichaPromocion) : null;
        if (accion == 3) {
            sistema.promociones().guardar(sesion, new PromocionPorDia(anterior.id(), anterior.nombre(),
                    anterior.diasAplicables(), anterior.porcentaje(), !anterior.activa()));
            ui.mostrar("Promoción actualizada", anterior.activa() ? "Desactivada" : "Activada");
            return;
        }
        String id = anterior == null ? nuevoCodigo(existentes, PromocionPorDia::id) : anterior.id();
        String nombre = ui.entrada("Nombre de la promoción", anterior == null ? "" : anterior.nombre());
        BigDecimal porcentaje = decimal("Porcentaje de descuento", anterior == null ? "" : anterior.porcentaje().toPlainString());
        Set<DayOfWeek> dias = EnumSet.noneOf(DayOfWeek.class);
        if (anterior != null) dias.addAll(anterior.diasAplicables());
        while (true) {
            List<String> opciones = new ArrayList<>();
            opciones.add("Guardar días seleccionados");
            for (DayOfWeek dia : DayOfWeek.values()) {
                opciones.add((dias.contains(dia) ? "[✓] " : "[ ] ") + dia.getDisplayName(TextStyle.FULL, ESPANOL));
            }
            int indice = ui.opcion("Activa o desactiva cada día", opciones);
            if (indice == 0) {
                if (!dias.isEmpty()) break;
                ui.error("Selecciona al menos un día.");
                continue;
            }
            DayOfWeek dia = DayOfWeek.of(indice);
            if (!dias.add(dia)) dias.remove(dia);
        }
        sistema.promociones().guardar(sesion,
                new PromocionPorDia(id, nombre, dias, porcentaje, anterior == null || anterior.activa()));
        ui.mostrar("Promoción guardada", nombre);
    }

    private void pago() {
        Set<Integer> pagados = new HashSet<>();
        for (Pago pago : sistema.caja().pagos(sesion)) pagados.add(pago.pedidoId());
        Pedido pedido = elegir("Pedido sin pagar",
                sistema.pedidos().listar().stream().filter(p -> !pagados.contains(p.id())).toList(),
                Operaciones::resumenPedido);
        Pago.Metodo metodo = elegir("Método de pago", List.of(Pago.Metodo.values()), Operaciones::etiqueta);
        if (ui.confirmar("¿Registrar " + dinero(pedido.total()) + " por " + etiqueta(metodo) + "?"))
            ui.mostrar("Pago registrado", fichaPago(sistema.caja().registrarPago(sesion, pedido.id(), metodo)));
    }

    private void movimiento() {
        boolean ingreso = ui.opcion("Tipo de movimiento", List.of("Ingreso", "Egreso")) == 0;
        String concepto = ui.entrada("Concepto", "");
        sistema.caja().registrarMovimiento(sesion, concepto, decimal("Valor en COP", ""), ingreso);
        ui.mostrar("Movimiento registrado", concepto);
    }

    private void cerrarCaja() {
        mostrarCierre(sistema.caja().resumen(sesion));
        if (ui.confirmar("¿Confirmar cierre de caja para este día?"))
            mostrarCierre(sistema.caja().cerrarCaja(sesion));
    }

    private void cierres() {
        mostrarCierre(elegir("Historial de cierres", sistema.caja().cierres(sesion),
                c -> c.fecha() + " · Ingresos " + dinero(c.totalIngresos())));
    }

    private void mostrarCierre(CierreCaja cierre) {
        StringBuilder texto = new StringBuilder();
        texto.append(cierre.fecha()).append("\nIngresos ").append(dinero(cierre.totalIngresos()))
                .append("\nEgresos ").append(dinero(cierre.totalEgresos()))
                .append("\nSaldo en efectivo ").append(dinero(cierre.saldoEfectivo())).append("\n\n");
        for (MovimientoCaja m : cierre.movimientos())
            texto.append(m.fecha().toLocalTime().withNano(0)).append(" · ").append(m.descripcion())
                    .append(" · ").append(dinero(m.valor())).append('\n');
        ui.mostrar("Caja", texto.toString());
    }

    private void reporte() {
        String hoy = LocalDate.now().toString();
        LocalDate inicio = LocalDate.parse(ui.entrada("Fecha inicial (AAAA-MM-DD)", hoy));
        LocalDate fin = LocalDate.parse(ui.entrada("Fecha final (AAAA-MM-DD)", hoy));
        ReporteVentas reporte = sistema.caja().generarReporte(sesion, inicio, fin);
        String texto = inicio + " a " + fin + "\nPagos: " + reporte.pagos().size() + "\nTotal: "
                + dinero(reporte.totalVentas()) + "\n\n" + reporte.pagos().stream()
                .map(Operaciones::fichaPago).collect(java.util.stream.Collectors.joining("\n"));
        ui.mostrar("Reporte de ventas", texto);
    }

    private void respaldar() {
        Path destino = Path.of(Datos.texto(ui.entrada("Ruta del archivo de respaldo", "respaldo-" + LocalDate.now() + ".dat"), "Ruta"));
        sistema.respaldar(sesion, destino);
        ui.mostrar("Respaldo generado", destino.toAbsolutePath().toString());
    }

    private void restaurar() {
        Path origen = Path.of(Datos.texto(ui.entrada("Ruta del archivo a restaurar", ""), "Ruta"));
        if (ui.confirmar("¿Reemplazar los datos actuales con este respaldo?")) {
            sistema.restaurar(sesion, origen);
            ui.mostrar("Datos restaurados", origen.toAbsolutePath().toString());
        }
    }

    private <T> String nuevoCodigo(List<T> existentes, Function<T, String> clave) {
        String codigo = Datos.texto(ui.entrada("Código único", ""), "Código").toUpperCase(Locale.ROOT);
        if (existentes.stream().anyMatch(item -> clave.apply(item).equals(codigo)))
            throw new IllegalArgumentException("Ese código ya está registrado.");
        return codigo;
    }

    private <T> T elegir(String titulo, List<T> datos, Function<T, String> etiqueta) {
        if (datos.isEmpty()) {
            ui.mostrar(titulo, "No hay registros disponibles.");
            throw new Dialogos.Cancelado();
        }
        return datos.get(ui.opcion(titulo, datos.stream().map(etiqueta).toList()));
    }

    private BigDecimal decimal(String mensaje, String valor) {
        String entrada = ui.entrada(mensaje, valor).strip().replace(',', '.');
        if (!entrada.matches("[0-9]{1,12}([.][0-9]{1,4})?"))
            throw new IllegalArgumentException("Escribe un número con hasta cuatro decimales y sin separadores de miles.");
        return new BigDecimal(entrada);
    }

    private int entero(String mensaje, String valor) { return Integer.parseInt(ui.entrada(mensaje, valor).strip()); }

    private void mostrarLista(String titulo, List<String> lineas) {
        ui.mostrar(titulo, lineas.isEmpty() ? "No hay registros disponibles." : String.join("\n", lineas));
    }

    private static String ficha(Producto producto) {
        String prefijo = producto instanceof ProductoMenu base ? base.id() + " · " + etiqueta(base.tipo()) + " · " : "";
        return prefijo + producto.getDescripcion() + " · " + dinero(producto.getPrecio());
    }

    private static String fichaLinea(LineaPedido linea) {
        return linea.cantidad() + " × " + linea.producto().getDescripcion() + " · " + dinero(linea.calcularTotal());
    }

    private static String fichaCombo(ComboCatalogo entrada) {
        return entrada.id() + " · " + ficha(entrada.combo());
    }

    private static String fichaIngrediente(Ingrediente i) {
        return i.id() + " · " + i.nombre() + " · " + etiqueta(i.tipo()) + " · " + dinero(i.precio());
    }

    private static String fichaPromocion(PromocionPorDia p) {
        String dias = p.diasAplicables().stream().sorted().map(d -> d.getDisplayName(TextStyle.SHORT, ESPANOL))
                .collect(java.util.stream.Collectors.joining(", "));
        return p.id() + " · " + p.nombre() + " · " + p.porcentaje().toPlainString() + "% · " + dias
                + (p.activa() ? " · Activa" : " · Inactiva");
    }

    private static String resumenPedido(Pedido p) {
        return "#" + p.id() + " · " + p.cliente() + " · " + p.fecha().withNano(0) + " · "
                + etiqueta(p.estado()) + " · " + dinero(p.total());
    }

    private static String fichaPedido(Pedido p) {
        return resumenPedido(p) + "\n\n" + String.join("\n", p.lineas().stream().map(Operaciones::fichaLinea).toList())
                + "\n\nSubtotal " + dinero(p.calcularSubtotal()) + "\nDescuento " + dinero(p.descuento())
                + "\nTotal " + dinero(p.total());
    }

    private static String fichaCambio(CambioEstado c) {
        return c.fecha().withNano(0) + " · Pedido #" + c.pedidoId() + " · "
                + etiqueta(c.anterior()) + " → " + etiqueta(c.nuevo());
    }

    private static String fichaPago(Pago p) {
        return "Pedido #" + p.pedidoId() + " · " + p.fecha().withNano(0) + " · "
                + etiqueta(p.metodo()) + " · " + dinero(p.valor());
    }

    private static String etiqueta(Enum<?> e) {
        String texto = e.name().replace('_', ' ').toLowerCase(ESPANOL);
        return Character.toUpperCase(texto.charAt(0)) + texto.substring(1);
    }

    private static String dinero(BigDecimal valor) {
        return java.text.NumberFormat.getCurrencyInstance(ESPANOL).format(valor) + " COP";
    }
}
