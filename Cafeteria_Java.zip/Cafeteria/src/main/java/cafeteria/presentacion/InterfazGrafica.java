package cafeteria.presentacion;

import cafeteria.aplicacion.Acceso.Sesion;
import cafeteria.aplicacion.Sistema;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;
import java.util.List;

public final class InterfazGrafica implements InterfazUsuario, Dialogos {
    private static final Color MARRON = new Color(58, 36, 27);
    private static final Color CREMA = new Color(249, 245, 239);
    private final Sistema sistema;
    private final Runnable alCerrar;
    private final JFrame ventana = new JFrame("Cafetería · Sistema de pedidos");

    public InterfazGrafica(Sistema sistema, Runnable alCerrar) {
        this.sistema = sistema;
        this.alCerrar = alCerrar;
    }

    @Override public void iniciar() {
        ventana.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        ventana.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent evento) { alCerrar.run(); }
        });
        ventana.setMinimumSize(new Dimension(660, 460));
        ventana.setSize(850, 560);
        ventana.setLocationRelativeTo(null);
        iniciarSesion();
        ventana.setVisible(true);
    }

    private void iniciarSesion() {
        JPanel raiz = vista("Iniciar sesión", null);
        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false);
        JPanel formulario = new JPanel();
        formulario.setLayout(new BoxLayout(formulario, BoxLayout.Y_AXIS));
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(new EmptyBorder(26, 32, 26, 32));
        JTextField usuario = new JTextField(23);
        JPasswordField contrasena = new JPasswordField(23);
        JLabel etiquetaUsuario = new JLabel("Usuario");
        etiquetaUsuario.setLabelFor(usuario);
        JLabel etiquetaClave = new JLabel("Contraseña");
        etiquetaClave.setLabelFor(contrasena);
        JButton entrar = new JButton("Entrar");
        for (JComponent campo : List.of(etiquetaUsuario, usuario, etiquetaClave, contrasena, entrar)) {
            campo.setAlignmentX(Component.LEFT_ALIGNMENT);
            formulario.add(campo);
            formulario.add(Box.createVerticalStrut(8));
        }
        entrar.addActionListener(evento -> Operaciones.ejecutar(this, () -> {
            char[] caracteres = contrasena.getPassword();
            try {
                Sesion sesion = sistema.acceso().iniciar(usuario.getText(), new String(caracteres));
                escritorio(sesion);
            } finally {
                Arrays.fill(caracteres, '\0');
                contrasena.setText("");
            }
        }));
        centro.add(formulario);
        raiz.add(centro, BorderLayout.CENTER);
        instalar(raiz);
        ventana.getRootPane().setDefaultButton(entrar);
        SwingUtilities.invokeLater(usuario::requestFocusInWindow);
    }

    private void escritorio(Sesion sesion) {
        JButton salir = new JButton("Cerrar sesión");
        salir.addActionListener(e -> iniciarSesion());
        JPanel raiz = vista("Cafetería", salir);
        JTabbedPane pestanas = new JTabbedPane();
        Map<String, JPanel> grupos = new LinkedHashMap<>();
        for (Opcion opcion : new Operaciones(sistema, this, sesion).opciones()) {
            JPanel grupo = grupos.computeIfAbsent(opcion.grupo(), nombre -> {
                JPanel botones = new JPanel(new GridLayout(0, 1, 0, 8));
                JPanel contenedor = new JPanel(new BorderLayout());
                contenedor.setBorder(new EmptyBorder(20, 22, 20, 22));
                contenedor.add(botones, BorderLayout.NORTH);
                pestanas.addTab(nombre, new JScrollPane(contenedor));
                return botones;
            });
            JButton boton = new JButton(opcion.nombre());
            boton.setHorizontalAlignment(SwingConstants.LEFT);
            boton.setBorder(new EmptyBorder(11, 14, 11, 14));
            boton.addActionListener(e -> Operaciones.ejecutar(this, opcion.accion()));
            grupo.add(boton);
        }
        JPanel cuerpo = new JPanel(new BorderLayout(0, 10));
        cuerpo.setOpaque(false);
        cuerpo.setBorder(new EmptyBorder(16, 22, 16, 22));
        cuerpo.add(new JLabel("Sesión · " + sesion.rol()), BorderLayout.NORTH);
        cuerpo.add(pestanas, BorderLayout.CENTER);
        raiz.add(cuerpo, BorderLayout.CENTER);
        instalar(raiz);
        ventana.getRootPane().setDefaultButton(null);
    }

    private JPanel vista(String nombre, JButton boton) {
        JPanel raiz = new JPanel(new BorderLayout());
        raiz.setBackground(CREMA);
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(MARRON);
        encabezado.setBorder(new EmptyBorder(17, 22, 17, 22));
        JLabel titulo = new JLabel(nombre);
        titulo.setForeground(Color.WHITE);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 24f));
        encabezado.add(titulo, BorderLayout.WEST);
        if (boton != null) encabezado.add(boton, BorderLayout.EAST);
        raiz.add(encabezado, BorderLayout.NORTH);
        return raiz;
    }

    private void instalar(JPanel panel) {
        ventana.setContentPane(panel);
        ventana.revalidate();
        ventana.repaint();
    }

    @Override public String entrada(String titulo, String inicial) {
        String valor = JOptionPane.showInputDialog(ventana, titulo, inicial);
        if (valor == null) throw new Cancelado();
        return valor;
    }

    @Override public String clave() {
        throw new UnsupportedOperationException("El formulario de acceso gestiona la contraseña.");
    }

    @Override public int opcion(String titulo, List<String> opciones) {
        JList<String> lista = new JList<>(opciones.toArray(String[]::new));
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lista.setSelectedIndex(0);
        lista.setVisibleRowCount(Math.min(opciones.size(), 9));
        JScrollPane desplazamiento = new JScrollPane(lista);
        desplazamiento.setPreferredSize(new Dimension(530, 40 + Math.min(opciones.size(), 9) * 20));
        JTextArea instruccion = texto(titulo);
        JPanel contenido = new JPanel(new BorderLayout(0, 8));
        contenido.add(instruccion, BorderLayout.NORTH);
        contenido.add(desplazamiento, BorderLayout.CENTER);
        String[] botones = {"Aceptar", "Volver"};
        int respuesta = JOptionPane.showOptionDialog(ventana, contenido, "Seleccionar",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, botones, botones[0]);
        if (respuesta != JOptionPane.OK_OPTION || lista.getSelectedIndex() < 0) throw new Cancelado();
        return lista.getSelectedIndex();
    }

    @Override public boolean confirmar(String titulo) {
        return JOptionPane.showConfirmDialog(ventana, titulo, "Confirmación",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    private static JTextArea texto(String contenido) {
        JTextArea area = new JTextArea(contenido);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        return area;
    }

    @Override public void mostrar(String titulo, String contenido) {
        JTextArea area = texto(contenido);
        area.setBorder(new EmptyBorder(10, 10, 10, 10));
        area.setColumns(54);
        area.setRows(Math.min(16, Math.max(3, contenido.split("\n").length + 2)));
        area.setCaretPosition(0);
        JOptionPane.showMessageDialog(ventana, new JScrollPane(area), titulo, JOptionPane.PLAIN_MESSAGE);
    }

    @Override public void error(String contenido) {
        JOptionPane.showMessageDialog(ventana, contenido, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
