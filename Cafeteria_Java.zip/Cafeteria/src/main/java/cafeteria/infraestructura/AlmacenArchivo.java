package cafeteria.infraestructura;

import cafeteria.aplicacion.repositorio.*;
import cafeteria.dominio.*;
import java.io.*;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

public final class AlmacenArchivo implements ProductoRepository, PedidoRepository, PromocionRepository,
        CajaRepository, RespaldoRepository, AutoCloseable {
    private static final Set<String> TIPOS_JAVA = Set.of(
            "java.lang.Object", "java.lang.Enum", "java.lang.Number", "java.lang.String",
            "java.math.BigDecimal", "java.math.BigInteger", "java.time.Ser",
            "java.time.DayOfWeek", "java.time.LocalDate", "java.time.LocalDateTime",
            "java.util.CollSer", "java.util.ImmutableCollections$ListN",
            "java.util.ImmutableCollections$List12", "java.util.ImmutableCollections$SetN",
            "java.util.ImmutableCollections$Set12");

    private record Estado(List<ProductoMenu> productos, List<Ingrediente> ingredientes,
                          List<ComboCatalogo> combos, List<PromocionPorDia> promociones, List<Pedido> pedidos, List<Pago> pagos,
                          List<MovimientoCaja> movimientos, List<CierreCaja> cierres) implements Serializable {}

    private final Path archivo;
    private final FileChannel canal;
    private final FileLock bloqueo;
    private Estado estado;

    public AlmacenArchivo(Path directorio) throws IOException {
        Files.createDirectories(directorio);
        archivo = directorio.resolve("cafeteria.dat").toAbsolutePath().normalize();
        canal = FileChannel.open(archivo.resolveSibling("cafeteria.lock"), StandardOpenOption.CREATE,
                StandardOpenOption.WRITE);
        try {
            bloqueo = canal.tryLock();
            if (bloqueo == null) throw new IOException("Ya hay una instancia usando esta carpeta de datos.");
            estado = Files.notExists(archivo) ? datosIniciales() : leer(archivo);
        } catch (OverlappingFileLockException e) {
            canal.close();
            throw new IOException("Ya hay una instancia usando esta carpeta de datos.", e);
        } catch (IOException | RuntimeException e) {
            canal.close();
            throw e;
        }
    }

    @Override public void close() throws IOException {
        try {
            bloqueo.release();
        } finally {
            canal.close();
        }
    }

    @Override public List<ProductoMenu> listarProductos() { return estado.productos(); }
    @Override public List<Ingrediente> listarIngredientes() { return estado.ingredientes(); }
    @Override public List<ComboCatalogo> listarCombos() { return estado.combos(); }
    @Override public List<PromocionPorDia> listarPromociones() { return estado.promociones(); }
    @Override public List<Pedido> listarPedidos() { return estado.pedidos(); }
    @Override public List<Pago> listarPagos() { return estado.pagos(); }
    @Override public List<MovimientoCaja> listarMovimientos() { return estado.movimientos(); }
    @Override public List<CierreCaja> listarCierres() { return estado.cierres(); }

    @Override public void guardarProducto(ProductoMenu producto) {
        guardarProductos(reemplazar(listarProductos(), ProductoMenu::id, producto));
    }

    @Override public void eliminarProducto(String id) {
        guardarProductos(listarProductos().stream().filter(p -> !p.id().equals(id)).toList());
    }

    @Override public void guardarIngrediente(Ingrediente ingrediente) {
        guardarIngredientes(reemplazar(listarIngredientes(), Ingrediente::id, ingrediente));
    }

    @Override public void eliminarIngrediente(String id) {
        guardarIngredientes(listarIngredientes().stream().filter(i -> !i.id().equals(id)).toList());
    }

    private void guardarProductos(List<ProductoMenu> productos) {
        guardar(new Estado(productos, listarIngredientes(), listarCombos(), listarPromociones(), listarPedidos(), listarPagos(),
                listarMovimientos(), listarCierres()));
    }

    private void guardarIngredientes(List<Ingrediente> ingredientes) {
        guardar(new Estado(listarProductos(), ingredientes, listarCombos(), listarPromociones(), listarPedidos(), listarPagos(),
                listarMovimientos(), listarCierres()));
    }

    @Override public void guardarCombo(ComboCatalogo combo) {
        guardarCombos(agregar(listarCombos(), combo));
    }

    @Override public void eliminarCombo(String id) {
        guardarCombos(listarCombos().stream().filter(c -> !c.id().equals(id)).toList());
    }

    private void guardarCombos(List<ComboCatalogo> combos) {
        guardar(new Estado(listarProductos(), listarIngredientes(), combos, listarPromociones(), listarPedidos(),
                listarPagos(), listarMovimientos(), listarCierres()));
    }

    @Override public void guardarPromocion(PromocionPorDia promocion) {
        guardar(new Estado(listarProductos(), listarIngredientes(), listarCombos(),
                reemplazar(listarPromociones(), PromocionPorDia::id, promocion), listarPedidos(), listarPagos(),
                listarMovimientos(), listarCierres()));
    }

    @Override public void guardarPedido(Pedido pedido) {
        guardar(new Estado(listarProductos(), listarIngredientes(), listarCombos(), listarPromociones(),
                reemplazar(listarPedidos(), Pedido::id, pedido), listarPagos(), listarMovimientos(), listarCierres()));
    }

    @Override public void guardarPago(Pago pago) {
        guardar(new Estado(listarProductos(), listarIngredientes(), listarCombos(), listarPromociones(), listarPedidos(),
                agregar(listarPagos(), pago), listarMovimientos(), listarCierres()));
    }

    @Override public void guardarMovimiento(MovimientoCaja movimiento) {
        guardar(new Estado(listarProductos(), listarIngredientes(), listarCombos(), listarPromociones(), listarPedidos(), listarPagos(),
                agregar(listarMovimientos(), movimiento), listarCierres()));
    }

    @Override public void guardarCierre(CierreCaja cierre) {
        guardar(new Estado(listarProductos(), listarIngredientes(), listarCombos(), listarPromociones(), listarPedidos(), listarPagos(),
                listarMovimientos(), agregar(listarCierres(), cierre)));
    }

    @Override public void respaldar(Path destino) {
        Path ruta = destino.toAbsolutePath().normalize();
        if (Files.exists(ruta)) throw new IllegalArgumentException("El destino del respaldo ya existe.");
        if (ruta.equals(archivo)) throw new IllegalArgumentException("Usa una ruta distinta al archivo de datos.");
        escribir(ruta, estado, false);
    }

    @Override public void restaurar(Path origen) {
        guardar(leer(origen));
    }

    private void guardar(Estado nuevo) {
        escribir(archivo, nuevo, true);
        estado = nuevo;
    }

    private static void escribir(Path destino, Estado datos, boolean reemplazar) {
        try {
            Path temporal = Files.createTempFile(destino.getParent(), ".cafeteria-", ".tmp");
            try {
                try (FileOutputStream archivoTemporal = new FileOutputStream(temporal.toFile());
                     ObjectOutputStream salida = new ObjectOutputStream(archivoTemporal)) {
                    salida.writeObject(datos);
                    salida.flush();
                    archivoTemporal.getFD().sync();
                }
                if (reemplazar)
                    Files.move(temporal, destino, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                else Files.move(temporal, destino);
            } finally {
                Files.deleteIfExists(temporal);
            }
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo guardar la información: " + e.getMessage(), e);
        }
    }

    private static Estado leer(Path origen) {
        try (ObjectInputStream entrada = new ObjectInputStream(Files.newInputStream(origen))) {
            entrada.setObjectInputFilter(AlmacenArchivo::filtrar);
            if (entrada.readObject() instanceof Estado datos) return datos;
            throw new IOException("Formato incompatible.");
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo abrir el archivo de datos: " + e.getMessage(), e);
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("El archivo de datos es incompatible.", e);
        }
    }

    private static ObjectInputFilter.Status filtrar(ObjectInputFilter.FilterInfo info) {
        if (info.depth() > 128 || info.references() > 2_000_000 || info.arrayLength() > 500_000)
            return ObjectInputFilter.Status.REJECTED;
        Class<?> tipo = info.serialClass();
        if (tipo == null) return ObjectInputFilter.Status.UNDECIDED;
        while (tipo.isArray()) tipo = tipo.getComponentType();
        String nombre = tipo.getName();
        if (tipo.isPrimitive() || tipo == Estado.class || nombre.startsWith("cafeteria.dominio.")
                || TIPOS_JAVA.contains(nombre)) return ObjectInputFilter.Status.ALLOWED;
        return ObjectInputFilter.Status.REJECTED;
    }

    private static <T, K> List<T> reemplazar(List<T> anteriores, Function<T, K> clave, T valor) {
        List<T> copia = new ArrayList<>(anteriores);
        for (int i = 0; i < copia.size(); i++) {
            if (clave.apply(copia.get(i)).equals(clave.apply(valor))) {
                copia.set(i, valor);
                return List.copyOf(copia);
            }
        }
        copia.add(valor);
        return List.copyOf(copia);
    }

    private static <T> List<T> agregar(List<T> anteriores, T valor) {
        List<T> copia = new ArrayList<>(anteriores);
        copia.add(valor);
        return List.copyOf(copia);
    }

    private static Estado datosIniciales() {
        var bebida = ProductoMenu.Tipo.BEBIDA;
        var plato = ProductoMenu.Tipo.PLATO;
        return new Estado(List.of(new ProductoMenu("CAF", "Café", bebida, BigDecimal.valueOf(4500)),
                new ProductoMenu("CHOC", "Chocolate", bebida, BigDecimal.valueOf(6500)),
                new ProductoMenu("ARE", "Arepa", plato, BigDecimal.valueOf(5000)),
                new ProductoMenu("SAN", "Sándwich", plato, BigDecimal.valueOf(9500))),
                List.of(new Ingrediente("LEC", "Leche", bebida, BigDecimal.valueOf(1500)),
                        new Ingrediente("SIR", "Sirope", bebida, BigDecimal.valueOf(1200)),
                        new Ingrediente("QUE", "Queso", plato, BigDecimal.valueOf(2000)),
                        new Ingrediente("JAM", "Jamón", plato, BigDecimal.valueOf(2500))),
                List.of(), List.of(), List.of(), List.of(), List.of(), List.of());
    }
}
