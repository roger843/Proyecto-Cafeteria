package cafeteria;

import cafeteria.aplicacion.*;
import cafeteria.infraestructura.AlmacenArchivo;
import cafeteria.presentacion.ConsolaUI;
import cafeteria.presentacion.InterfazGrafica;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.nio.file.Path;
import java.time.Clock;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public final class Main {
    private Main() {}

    public static void main(String[] args) {
        boolean grafica = args.length == 0 || args[0].equals("--gui");
        if (args.length > 1 || (args.length == 1 && !grafica && !args[0].equals("--consola"))) {
            System.err.println("Uso: java -jar cafeteria.jar [--gui | --consola]");
            System.exit(2);
        }
        if (grafica && GraphicsEnvironment.isHeadless()) {
            System.err.println("Se necesita un escritorio para Swing. Ejecuta con --consola.");
            System.exit(2);
        }
        if (grafica) SwingUtilities.invokeLater(() -> iniciar(true));
        else iniciar(false);
    }

    private static void iniciar(boolean grafica) {
        try {
            Path carpeta = Path.of(System.getProperty("cafeteria.datos", "datos"));
            AlmacenArchivo almacen = new AlmacenArchivo(carpeta);
            if (grafica) {
                try {
                    new InterfazGrafica(servicios(almacen, Clock.systemDefaultZone()), () -> cerrar(almacen)).iniciar();
                } catch (RuntimeException e) {
                    cerrar(almacen);
                    throw e;
                }
            } else {
                try (almacen) {
                    new ConsolaUI(servicios(almacen, Clock.systemDefaultZone())).iniciar();
                }
            }
        } catch (IOException | RuntimeException e) {
            if (grafica) JOptionPane.showMessageDialog(null, e.getMessage(), "Cafetería", JOptionPane.ERROR_MESSAGE);
            else System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    static Sistema servicios(AlmacenArchivo almacen, Clock reloj) {
        PromocionService promociones = new PromocionService(almacen);
        PedidoService pedidos = new PedidoService(almacen, promociones, reloj);
        return new Sistema(new Acceso(), new ProductoService(almacen), promociones, pedidos,
                new CajaService(almacen, pedidos, reloj), almacen);
    }

    private static void cerrar(AlmacenArchivo almacen) {
        try {
            almacen.close();
        } catch (IOException e) {
            System.err.println("No se pudo cerrar el archivo de datos: " + e.getMessage());
        }
    }
}
