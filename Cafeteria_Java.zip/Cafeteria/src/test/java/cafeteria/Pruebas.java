package cafeteria;

import cafeteria.aplicacion.Acceso;
import cafeteria.aplicacion.Acceso.Rol;
import cafeteria.aplicacion.Sistema;
import cafeteria.dominio.*;
import cafeteria.infraestructura.AlmacenArchivo;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.stream.Stream;

public final class Pruebas {
    private static final ProductoMenu CAFE = new ProductoMenu("CAF", "Café", ProductoMenu.Tipo.BEBIDA, monto("4500"));
    private static final ProductoMenu AREPA = new ProductoMenu("ARE", "Arepa", ProductoMenu.Tipo.PLATO, monto("5000"));
    private static final Ingrediente LECHE = new Ingrediente("LEC", "Leche", ProductoMenu.Tipo.BEBIDA, monto("1500"));
    private static final Ingrediente SIROPE = new Ingrediente("SIR", "Sirope", ProductoMenu.Tipo.BEBIDA, monto("1200"));
    private static final Clock RELOJ = Clock.fixed(Instant.parse("2026-11-23T15:00:00Z"), ZoneId.of("America/Bogota"));
    private static final LocalDate LUNES = LocalDate.of(2026, 11, 23);
    private static int exitos;

    private Pruebas() {}

    public static void main(String[] args) throws Exception {
        probar("Decorator: composición de precio y descripción", Pruebas::decorator);
        probar("Decorator: reglas de compatibilidad y producto original", Pruebas::compatibilidad);
        probar("Builder: composición incremental, copia y requisitos", Pruebas::builder);
        probar("Observer: tres áreas, suscripción única y baja", Pruebas::observer);
        probar("Observer: reintentos y transiciones inválidas", Pruebas::transiciones);
        probar("Aplicación: permisos, menú y promociones", Pruebas::menuYPromociones);
        probar("Aplicación: pedido, estado, pago, movimientos, cierre y reporte", Pruebas::flujo);
        probar("Persistencia: bloqueo, reinicio y restauración", Pruebas::persistencia);
        probar("Persistencia: rechazo de archivo inválido y fallo controlado", Pruebas::falloControlado);
        System.out.println(exitos + " pruebas correctas.");
    }

    private static void decorator() {
        Producto leche = new Adicion(CAFE, LECHE);
        Producto ambos = new Adicion(leche, SIROPE);
        igual("Café", ambos.getNombre());
        igual("Café + Leche + Sirope", ambos.getDescripcion());
        dinero("7200", ambos.getPrecio());
        igual("Café + Leche", leche.getDescripcion());
        dinero("6000", leche.getPrecio());
        dinero("4500", CAFE.getPrecio());
    }

    private static void compatibilidad() {
        rechaza(IllegalArgumentException.class, () -> new Adicion(AREPA, LECHE));
        Producto arepa = new Adicion(AREPA, new Ingrediente("QUE", "Queso", AREPA.tipo(), monto("2000")));
        igual("Arepa + Queso", arepa.getDescripcion());
        igual("Arepa", AREPA.getDescripcion());
        dinero("7000", arepa.getPrecio());
    }

    private static void builder() {
        ComboBuilder builder = new ConstructorCombo().conNombre("Desayuno").agregarProducto(new Adicion(CAFE, LECHE));
        rechaza(IllegalArgumentException.class, builder::construir);
        Combo combo = builder.agregarProducto(AREPA).construir();
        igual("Desayuno (Café + Leche / Arepa)", combo.getDescripcion());
        dinero("11000", combo.getPrecio());
        builder.agregarProducto(CAFE);
        igual(2, combo.productos().size());
        igual(3, builder.construir().productos().size());
        rechaza(UnsupportedOperationException.class, () -> combo.productos().add(CAFE));
    }

    private static void observer() {
        List<CambioEstado> cocina = new ArrayList<>();
        List<CambioEstado> caja = new ArrayList<>();
        List<CambioEstado> mesero = new ArrayList<>();
        ObservadorCocina o1 = new ObservadorCocina(cocina::add);
        ObservadorCaja o2 = new ObservadorCaja(caja::add);
        ObservadorMesero o3 = new ObservadorMesero(mesero::add);
        Pedido pedido = pedido();
        pedido.agregarObservador(o1);
        pedido.agregarObservador(o1);
        pedido.agregarObservador(o2);
        pedido.agregarObservador(o3);
        pedido.notificarObservadores();
        igual(0, cocina.size());
        pedido = pedido.cambiarEstado(EstadoPedido.EN_PREPARACION, LocalDateTime.now(RELOJ));
        igual(0, cocina.size());
        pedido.notificarObservadores();
        pedido.notificarObservadores();
        igual(1, cocina.size());
        igual(cocina, caja);
        igual(cocina, mesero);
        igual(new CambioEstado(1, LocalDateTime.now(RELOJ), EstadoPedido.PENDIENTE, EstadoPedido.EN_PREPARACION),
                cocina.getFirst());
        pedido.quitarObservador(o2);
        pedido.cambiarEstado(EstadoPedido.LISTO, LocalDateTime.now(RELOJ)).notificarObservadores();
        igual(1, caja.size());
        igual(2, mesero.size());
        igual(2, cocina.size());
    }

    private static void transiciones() {
        Pedido inicial = pedido();
        rechaza(IllegalArgumentException.class, () -> inicial.cambiarEstado(EstadoPedido.LISTO, LocalDateTime.now(RELOJ)));
        Pedido activo = inicial.cambiarEstado(EstadoPedido.EN_PREPARACION, LocalDateTime.now(RELOJ));
        rechaza(IllegalArgumentException.class,
                () -> activo.cambiarEstado(EstadoPedido.EN_PREPARACION, LocalDateTime.now(RELOJ)));
        igual(EstadoPedido.PENDIENTE, inicial.estado());
        igual(1, activo.cambios().size());
    }

    private static void menuYPromociones() throws Exception {
        enCarpeta(ruta -> {
            try (AlmacenArchivo almacen = new AlmacenArchivo(ruta)) {
                Sistema sistema = Main.servicios(almacen, RELOJ);
                var admin = sesion(sistema, Rol.ADMIN);
                var mesero = sesion(sistema, Rol.MESERO);
                rechaza(IllegalArgumentException.class, () -> sistema.acceso().iniciar("admin", "incorrecta-de-prueba"));
                rechaza(IllegalStateException.class, () -> sistema.productos().eliminarProducto(mesero, CAFE.id()));
                sistema.productos().guardarProducto(admin,
                        new ProductoMenu(CAFE.id(), "Tinto", CAFE.tipo(), monto("3400")));
                igual("Tinto", sistema.productos().consultarMenu().getFirst().nombre());
                sistema.productos().eliminarProducto(admin, CAFE.id());
                igual(3, sistema.productos().consultarMenu().size());
                sistema.productos().guardarIngrediente(admin, new Ingrediente("MIE", "Miel", CAFE.tipo(), monto("500")));
                igual(5, sistema.productos().ingredientes().size());
                sistema.productos().eliminarIngrediente(admin, "MIE");
                igual(4, sistema.productos().ingredientes().size());
                sistema.promociones().guardar(admin, promocion("A", "10", true));
                sistema.promociones().guardar(admin, promocion("B", "15", true));
                dinero("150", sistema.promociones().calcularDescuento(monto("1000"), LUNES));
                dinero("0", sistema.promociones().calcularDescuento(monto("1000"), LUNES.plusDays(1)));
                sistema.promociones().guardar(admin, promocion("B", "15", false));
                dinero("100", sistema.promociones().calcularDescuento(monto("1000"), LUNES));
            }
        });
    }

    private static void flujo() throws Exception {
        enCarpeta(ruta -> {
            try (AlmacenArchivo almacen = new AlmacenArchivo(ruta)) {
                Sistema sistema = Main.servicios(almacen, RELOJ);
                var admin = sesion(sistema, Rol.ADMIN);
                var cocina = sesion(sistema, Rol.COCINA);
                var mesero = sesion(sistema, Rol.MESERO);
                var caja = sesion(sistema, Rol.CAJA);
                sistema.promociones().guardar(admin, promocion("LUN", "10", true));
                Combo combo = sistema.productos().iniciarCombo("Desayuno")
                        .agregarProducto(new Adicion(CAFE, LECHE)).agregarProducto(AREPA).construir();
                Pedido p = sistema.pedidos().confirmarPedido(mesero, "Mesa 1", List.of(new LineaPedido(combo, 2)));
                dinero("22000", p.calcularSubtotal());
                dinero("2200", p.descuento());
                dinero("19800", p.total());
                rechaza(IllegalStateException.class, () -> sistema.pedidos().cambiarEstado(mesero, p.id(), EstadoPedido.EN_PREPARACION));
                sistema.pedidos().cambiarEstado(cocina, p.id(), EstadoPedido.EN_PREPARACION);
                sistema.pedidos().cambiarEstado(cocina, p.id(), EstadoPedido.LISTO);
                sistema.pedidos().cambiarEstado(mesero, p.id(), EstadoPedido.ENTREGADO);
                igual(3, sistema.pedidos().avisos(cocina, Rol.COCINA).size());
                igual(3, sistema.pedidos().avisos(caja, Rol.CAJA).size());
                igual(3, sistema.pedidos().avisos(mesero, Rol.MESERO).size());
                rechaza(IllegalStateException.class, () -> sistema.pedidos().avisos(cocina, Rol.CAJA));
                Pago pago = sistema.caja().registrarPago(caja, p.id(), Pago.Metodo.TARJETA);
                dinero("19800", pago.valor());
                rechaza(IllegalStateException.class, () -> sistema.caja().registrarPago(caja, p.id(), Pago.Metodo.EFECTIVO));
                sistema.caja().registrarMovimiento(caja, "Base", monto("6000"), true);
                sistema.caja().registrarMovimiento(caja, "Compra", monto("2000"), false);
                CierreCaja cierre = sistema.caja().cerrarCaja(caja);
                dinero("25800", cierre.totalIngresos());
                dinero("2000", cierre.totalEgresos());
                dinero("4000", cierre.saldoEfectivo());
                igual(3, cierre.movimientos().size());
                rechaza(IllegalStateException.class, () -> sistema.caja().cerrarCaja(caja));
                igual(1, sistema.caja().cierres(caja).size());
                dinero("19800", sistema.caja().generarReporte(caja, LUNES, LUNES).totalVentas());
                dinero("0", sistema.caja().generarReporte(caja, LUNES.minusDays(1), LUNES.minusDays(1)).totalVentas());
                rechaza(IllegalArgumentException.class, () -> sistema.caja().generarReporte(caja, LUNES, LUNES.minusDays(1)));
            }
        });
    }

    private static void persistencia() throws Exception {
        enCarpeta(ruta -> {
            Path datos = ruta.resolve("datos");
            Path respaldo = ruta.resolve("respaldo.dat");
            try (AlmacenArchivo almacen = new AlmacenArchivo(datos)) {
                rechaza(IOException.class, () -> {
                    try (AlmacenArchivo duplicado = new AlmacenArchivo(datos)) { duplicado.listarPedidos(); }
                });
                Sistema sistema = Main.servicios(almacen, RELOJ);
                var admin = sesion(sistema, Rol.ADMIN);
                sistema.promociones().guardar(admin, promocion("LUN", "10", true));
                var combo = sistema.productos().iniciarCombo("Desayuno")
                        .agregarProducto(new Adicion(CAFE, LECHE)).agregarProducto(AREPA).construir();
                sistema.productos().guardarCombo(admin, new ComboCatalogo("DES", combo));
                rechaza(IllegalArgumentException.class,
                        () -> sistema.productos().guardarCombo(admin, new ComboCatalogo("DES", combo)));
                Pedido pedido = sistema.pedidos().confirmarPedido(admin, "Mesa 1", List.of(new LineaPedido(combo, 1)));
                sistema.pedidos().cambiarEstado(admin, pedido.id(), EstadoPedido.EN_PREPARACION);
                sistema.caja().registrarPago(admin, pedido.id(), Pago.Metodo.EFECTIVO);
                sistema.caja().cerrarCaja(admin);
                sistema.respaldar(admin, respaldo);
                rechaza(IllegalArgumentException.class, () -> sistema.respaldar(admin, respaldo));
                sistema.productos().eliminarProducto(admin, CAFE.id());
            }
            try (AlmacenArchivo almacen = new AlmacenArchivo(datos)) {
                Sistema sistema = Main.servicios(almacen, RELOJ);
                var admin = sesion(sistema, Rol.ADMIN);
                igual(3, sistema.productos().consultarMenu().size());
                igual("DES", sistema.productos().combos().getFirst().id());
                dinero("9900", sistema.pedidos().buscar(1).total());
                igual(1, sistema.pedidos().avisos(admin, Rol.CAJA).size());
                igual(1, sistema.caja().pagos(admin).size());
                igual(1, sistema.caja().cierres(admin).size());
                igual("Desayuno (Café + Leche / Arepa)", sistema.pedidos().buscar(1).lineas().getFirst().producto().getDescripcion());
                sistema.restaurar(admin, respaldo);
                igual(4, sistema.productos().consultarMenu().size());
                igual(1, sistema.pedidos().avisos(admin, Rol.MESERO).size());
            }
        });
    }

    private static void falloControlado() throws Exception {
        enCarpeta(ruta -> {
            Path datos = ruta.resolve("datos");
            Path invalido = Files.writeString(ruta.resolve("invalido.dat"), "contenido inválido");
            try (AlmacenArchivo almacen = new AlmacenArchivo(datos)) {
                Sistema sistema = Main.servicios(almacen, RELOJ);
                var admin = sesion(sistema, Rol.ADMIN);
                sistema.pedidos().confirmarPedido(admin, "Mesa", List.of(new LineaPedido(CAFE, 1)));
                rechaza(UncheckedIOException.class, () -> sistema.restaurar(admin, invalido));
                rechaza(UncheckedIOException.class, () -> sistema.respaldar(admin, ruta.resolve("ausente/copia.dat")));
                igual(1, sistema.pedidos().listar().size());
            }
            try (AlmacenArchivo almacen = new AlmacenArchivo(datos)) {
                igual(1, almacen.listarPedidos().size());
            }
        });
    }

    private static Pedido pedido() {
        return new Pedido(1, "Mesa", LocalDateTime.now(RELOJ), List.of(new LineaPedido(CAFE, 1)), monto("0"));
    }

    private static PromocionPorDia promocion(String id, String porcentaje, boolean activa) {
        return new PromocionPorDia(id, "Lunes", Set.of(DayOfWeek.MONDAY), monto(porcentaje), activa);
    }

    private static Acceso.Sesion sesion(Sistema sistema, Rol rol) {
        String usuario = rol.name().toLowerCase(Locale.ROOT);
        String clave = System.getenv("CAFETERIA_CLAVE_" + rol.name());
        return sistema.acceso().iniciar(usuario, clave == null || clave.isBlank() ? usuario + "123" : clave);
    }

    private static BigDecimal monto(String valor) { return new BigDecimal(valor); }

    private static void dinero(String esperado, BigDecimal real) {
        if (monto(esperado).compareTo(real) != 0)
            throw new AssertionError("Esperado " + esperado + ", recibido " + real);
    }

    private static void igual(Object esperado, Object real) {
        if (!Objects.equals(esperado, real))
            throw new AssertionError("Esperado " + esperado + ", recibido " + real);
    }

    private static void rechaza(Class<? extends Exception> tipo, Accion accion) {
        try {
            accion.ejecutar();
        } catch (Exception e) {
            if (tipo.isInstance(e)) return;
            throw new AssertionError("Se esperaba " + tipo.getSimpleName(), e);
        }
        throw new AssertionError("No se lanzó " + tipo.getSimpleName());
    }

    private static void probar(String nombre, Accion accion) throws Exception {
        accion.ejecutar();
        exitos++;
        System.out.println("OK " + nombre);
    }

    private static void enCarpeta(AccionArchivo accion) throws Exception {
        Path ruta = Files.createTempDirectory("cafeteria-pruebas-");
        try {
            accion.ejecutar(ruta);
        } finally {
            try (Stream<Path> rutas = Files.walk(ruta)) {
                for (Path archivo : rutas.sorted(Comparator.reverseOrder()).toList()) Files.delete(archivo);
            }
        }
    }

    @FunctionalInterface private interface Accion { void ejecutar() throws Exception; }
    @FunctionalInterface private interface AccionArchivo { void ejecutar(Path ruta) throws Exception; }
}
